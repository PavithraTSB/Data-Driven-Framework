package com.ibm.magentotest;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.magentopages.HomePage;
import com.ibm.magentopages.LoginPage;
import com.ibm.magentopages.MyAccountPage;
import com.ibm.utilities.PropertiesFileHandler;

import jdk.nashorn.internal.runtime.PrototypeObject;

public class MagentoTest {
	
	public static void main(String[] args) throws IOException  {
		
		String file="./TestData/magentodata.properties";
		
		//Location //Properties handler
		PropertiesFileHandler propFileHandler = new PropertiesFileHandler();
		HashMap<String, String> data= propFileHandler.getPropertiesAsMap(file);
		
		String url = data.get("url");
		String userName=data.get("username");
		String password=data.get("password");
		String expectedTitle=data.get("expectedtitle");
		
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		WebDriverWait wait=new WebDriverWait(driver, 60);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);	
		driver.get(url);
		
		HomePage home=new HomePage(driver);
		home.clickOnMyAccountIcon();

		
		LoginPage login=new LoginPage(driver);
		login.enterEmailAddress(userName);
		login.enterPassword(password);
		login.clickOnLogin();
		
		MyAccountPage myAccount=new MyAccountPage(driver, wait);
		String actualTitle= myAccount.getCurrentTitle();
		  
		if(actualTitle.equals(expectedTitle))
		{
			System.out.println("Test Passed");
			propFileHandler.setKeyAndValue(file, "TestResult", "Test Passed");
		}
		else
		{
			System.out.println("Test failed");
			propFileHandler.setKeyAndValue(file, "TestResult", "Test Failed");
		}
		
		myAccount.clickOnLogOut();
		
	}

}
