package com.ibm.magentopages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	
	@FindBy(id="email")
	WebElement emailEle;
	
	@FindBy(how=How.ID,using="pass")
	WebElement passEle;
	
	@FindBy(xpath="//button[@type='submit']")
	WebElement loginEle;
	

	
	public LoginPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	public void enterEmailAddress(String userName)
	{
		emailEle.sendKeys(userName);
	}
	
	public void enterPassword(String password)
	{
		passEle.sendKeys(password);
	}
	
	public void clickOnLogin()
	{
		loginEle.click();
	}
	
}
